package com.thanggun99.tank90.main;

import com.thanggun99.tank90.guis.GUI;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        GUI gui = new GUI();
        gui.setVisible(true);
    }
}
