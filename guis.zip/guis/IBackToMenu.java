package com.thanggun99.tank90.guis;

/**
 * Created by Thanggun99 on 08/02/2017.
 */

public interface IBackToMenu {
    void backToMenu();
}
