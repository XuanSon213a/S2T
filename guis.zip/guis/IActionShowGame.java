package com.thanggun99.tank90.guis;

/**
 * Created by ThangIKCU on 5/05/2016.
 */
public interface IActionShowGame {
    void showGame();
}
